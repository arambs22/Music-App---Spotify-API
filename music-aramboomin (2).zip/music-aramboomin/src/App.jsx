import {Routes, Route} from 'react-router-dom';
import './App.css'
import Dashboard from './assets/Components/Dashboard';
import Login from './assets/Components/Login';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login/>}/>
      <Route path="/" element={<Dashboard/>}/>
    </Routes>
  )
}
