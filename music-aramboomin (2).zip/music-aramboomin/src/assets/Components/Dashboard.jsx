import React, { useState } from 'react';
import { fetchSpotifyApi } from '../../API/spotifyAPI';
import "./Dashboard.css";

const Dashboard = () => {

    const types = [
        "album", "playlist", "track", "show", "episode", "audiobook"
    ];

    const [form, setForm] = useState({
        search: '',
        artist: ''
    });

    const [Option, setOption] = useState('');
    
    const [results, setResults] = useState([]);

    const handleSearch = async() => {

        const params = new URLSearchParams();
        params.append('q', encodeURIComponent(`remaster track:${form.search} artist:${form.artist}`));
        params.append('type', Option);

        const queryString = params.toString();
        const url = 'https://api.spotify.com/v1/search';

        const UpdatedURL = `${url}?${queryString}`;
        const token = `Bearer ${localStorage.getItem('token')}`;

        const response = await fetchSpotifyApi(
            UpdatedURL,
            'GET',
            null,
            'application/json',
            token
        ); 
        console.log(response);
        setResults(response.tracks.items);
    };

    const handlePlayMusic = async (song) => {
        const token = `Bearer ${localStorage.getItem('token')}`;
        const data = {
          uris: [song.uri],
        };
        const id_device = '55d22bdc7255d83a4272c5f89c4d30a4332e35c2';
        const playSong = await fetchSpotifyApi(
          `https://api.spotify.com/v1/me/player/play?device_id=${id_device}`,
          'PUT',
          JSON.stringify(data),
          'application/json',
          token
        );
        console.log(playSong);
    };

    const getDeviceId = async () => {
        const token = `Bearer ${localStorage.getItem('token')}`;
        const response = await fetchSpotifyApi(
          `https://api.spotify.com/v1/me/player/devices`,
          'GET',
          null,
          'application/json',
          token
        );
        console.log(response);
        return response.devices.id;
    };

    const handleGetToken = async () => {
        // stored in the previous step
        const urlParams = new URLSearchParams(window.location.search);
        let code = urlParams.get('code');
        let codeVerifier = localStorage.getItem('code_verifier');
        console.log({ codeVerifier });
        const url = 'https://accounts.spotify.com/api/token';
        const clientId = 'a30f622efbd64e249fec05621e8b0ce5';
        const redirectUri = 'http://localhost:5173/';
        const payload = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            client_id: clientId,
            grant_type: 'authorization_code',
            code,
            redirect_uri: redirectUri,
            code_verifier: codeVerifier,
          }),
        };
    
        const body = await fetch(url, payload);
        const response = await body.json();
    
        localStorage.setItem('token', response.access_token);
    };
    
    const handleChange = (e) => {
        console.log(e.target.value);
        const NewValues = {
            ...form,
            [e.target.name]: e.target.value,
        }
        setForm(NewValues);
        console.log(NewValues);
        handleSearch();
    };

    const handleSelectChange = (e) =>{
        console.log(e.target.value)
        setOption(e.target.value)
    };

    return (
        <div className="main-page">
            <div className='container'>
                <div className='search-container'>
                    <input className='input'
                        placeholder='Search for Music'
                        type='text'
                        name='search'
                        value={form.search}
                        onChange={handleChange}
                    />
                    <select name="types" className="select" onChange={handleSelectChange}>
                        {types.map((item) => (
                            <option key={item} value={item}>
                                {item}
                            </option>
                        ))}
                    </select>
                </div>
    
                <div className='input-container'>
                    <input className='input'
                        placeholder='Artist'
                        type='text'
                        name='artist'
                        value={form.artist}
                        onChange={handleChange}
                    />
                    <button type='button' className='button' onClick={handleGetToken}>Get Token</button>
                    <button type='button' className='button' onClick={getDeviceId}>Get Device ID</button>
                </div>

                {results.length > 0 && (
                    <div className="h-[100%] w-[110%] overflow-auto">
                    {results.map((item, idx) => (
                        <div
                        key={item.id}
                        className="text-white flex justify-evenly items-center"
                        >
                        <div className="w-[30%] p-3 flex items-end">
                            <img src={item.album.images[0].url} width={150} />
                        </div>
                        <div className=" w-[70%] flex">
                            <div className="w-1/2 ">
                            <p className="text-[20px]"> {item.name}</p>
                            <p className="text-[15px]">{`${item.artists[0].name}`}</p>
                            </div>
                            <div className="w-1/2">
                            <button
                                className="bg-[#da1d1d] w-[40px] h-[40px] rounded-[100%] text-[15px] p-1 font-bold "
                                onClick={() => handlePlayMusic(item)}
                            >
                                ➤
                            </button>
                            </div>
                        </div>
                        </div>
                    ))}
                    </div>
                )}            
            </div>
        </div>
    );
    
};

export default Dashboard;