import React, { useState } from 'react';
import { fetchSpotifyApi } from "../../API/spotifyAPI";
import { useNavigate } from 'react-router-dom';
import "./Login.css";
import { authFLow, getDataAuth} from '../../setup';

const Login = () => {

  const [form, setForm] = useState({
    username: '',
    password: '',
  });  

  const navigate = useNavigate();

  const handleOnChange = (e) => {
    const newValues = {
      ...form,
      [e.target.name]: e.target.value,
    };
    setForm(newValues);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleLogin();
    }
  };

  const handleLogin = async () => {
    if(form.username === 'a01642781@tec.mx' && form.password === 'Abs268435sba$') {
      const codeChallengeProm = await getDataAuth();
      authFLow(codeChallengeProm);
    } else {
      window.alert('Contraseña o usuario incorrectos');
    }
    /*
    const client_id = 'a30f622efbd64e249fec05621e8b0ce5';
    const client_secret = 'e18e7df4cfce455b8b7d6bb5e9bccaa2';
    const url = "https://accounts.spotify.com/api/token";
    const body = 'grant_type=client_credentials';
    const token = 'Basic ' +btoa(client_id + ':' + client_secret);

    const response = await fetchSpotifyApi(url, 'POST', body,'application/x-www-form-urlencoded', token, );
    
    localStorage.setItem('token', response.access_token);
    navigate('/dashboard');
    console.log(response);
    */
  };

  return (
    <div className="dashboard-page">
      <h2>Evil Spotify</h2>
      <div className='dashboard-page-int'>
        <div className="group">
          <h3>Username:</h3>
          <input
            type="text"
            id="username"
            value={form.username} 
            onChange={handleOnChange} 
            name="username"
          />
        </div>
        <div className="group">
          <h3>Password:</h3>
          <input
            type="password"
            id="password"
            value={form.password}
            onChange={handleOnChange}
            onKeyDown={handleKeyPress} // Add this line
            name="password"
          />
        </div>
        <button className="login" onClick={handleLogin}>Login</button>
      </div>
    </div>
  );
}

export default Login;
